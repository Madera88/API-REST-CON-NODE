var mysql = require("mysql"); // modulo Mysql
var app = require("./app.js"); //carga en app la configuracion del archivo app.js
var port = 3700; // puerto en el que establece la conexion

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "personas",
});

// funcion de conexion a la BBDD
con.connect(function (err) {
  if (err) throw "Error al conectarse a la BBDD "+err;

  app.listen(port, () => {
    console.log("Conexion establecida con MYSQL y con la BBDD Personas");
    console.log("Servidor corriendo correctamente en ur: localhost:3700");
  });
});

//rutas
/*app.metodo("/url,request=datos de la peticion, res =respuesta "){
    res.status(exitosa=200).send({json a enviar})*/
app.get("/", (req, res) => {
  res.status(200).send("<h1>Web backend con Node de Iván<h1>");
});

app.get("/saludo", (req, res) => {
  res.status(200).send({
    message: "Hola mundo desde mi API con NODE",
  });
});

//Peticion get
app.get("/personas", (req, res) => {
  //consulta a la BBDD
  con.query("SELECT * FROM persona", function (err, result, fields) {
    if (err) throw err;
    
    // si es OK muestra por la consola de NODE la salida
    if (res.status(200)) {
      console.log(result);
      console.log(result.length);
      //Imprimo con send

      var aux="";

      result.forEach(element => {
        aux+=`<tr><td> Nombre: ${element.Nombre} , Apellidos: ${element.Apellido}<td><tr>`;
        
      });
        res.status(200).send("<table>"+ aux+ "</table>");
    }
  })
});


// Peticion post- añadir recursos
app.post("/incluirPersonas", (req, res) => {
    //consulta a la BBDD
    var nombre="'"+req.param('Nombre')+"'";
    var apellidos="'"+req.param('Apellido')+"'";   
    con.query("INSERT INTO persona(Nombre,Apellido) VALUES ("+nombre+","+apellidos+");" ,function (err, result) {
      if (err) throw err;
      
      // si es OK muestra por la consola de NODE la salida
      if (res.status(200)) {
        console.log("Se ha añadido la persona con nombre  y apellido"+nombre +" "+apellidos );
      }
    })
  });

  // Peticion delete- añadir recursos
app.delete("/borrarPersonas/:id", (req, res) => {
    //consulta a la BBDD
    
    var IdPersona=req.params.id;
    con.query("delete from persona where Id="+IdPersona ,function (err, result) {
      if (err) throw err;
      
      // si es OK muestra por la consola de NODE la salida
      if (res.status(200)) {
        console.log("Se ha eliminado la persona con Id "+IdPersona );
      }
    })
  });

  // Peticion put- añadir recursos
  app.put("/actualizarPersonas", (req, res) => {
    //consulta a la BBDD
    
    var IdPersona=req.param('id');
    var nombre="'"+req.param('Nombre')+"'";
    var apellidos="'"+req.param('Apellido')+"'";  
    con.query("update  persona set Nombre="+nombre+" , Apellido="+apellidos+" WHERE Id="+IdPersona ,function (err, result) {
      if (err) throw err;
      
      // si es OK muestra por la consola de NODE la salida
      if (res.status(200)) {
        console.log("Se ha actaulizado la persona con Id "+IdPersona );
      }
    })
  });
  