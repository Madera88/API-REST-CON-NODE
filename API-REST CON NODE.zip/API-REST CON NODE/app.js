"use strict";

var express = require("express"); // modulo express
var bodyParser = require("body-parser"); // modulo body-parse sirve para back envie .json

var app = express(); // modulo express se carga en variable app

// archivos rutas

//middlewares se ejecuta antes que la ruta
app.use(bodyParser.urlencoded({ extended: false })); // cnfig necesaria
app.use(bodyParser.json()); //cualquier peticion lo convierte en Json


//exportar
module.exports = app; // exportas la variable app que es requerida en index.js
